<?php 

$servername = "193.107.71.20";
$username = "dev101_finance_dashboard_user";
$password = "+v9&^Lko4f[c";
$dbname = "dev101_finance_dashboard";

?>